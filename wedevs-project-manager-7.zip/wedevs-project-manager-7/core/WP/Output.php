<?php

namespace WeDevs\PM\Core\WP;

class Output {

	public static function home_page() {
		echo pm_root_element(); //phpcs:ignore
	}
}
