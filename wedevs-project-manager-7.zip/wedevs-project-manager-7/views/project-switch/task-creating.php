<div class="pm-cteate-task pm-global" id="pmcteatetask">
    <div class="inner">
        
        <form class="new-task-form"  id="newtaskform">
            <div >
                <input id="task-title" type="text" placeholder="<?php esc_attr_e( 'Task title', 'wedevs-project-manager' ); ?>">
                
            </div>
            <div class="select-project"></div>
        </form>
        
    </div>
    <div class="pmbackoverlay" ></div>
    
</div>
