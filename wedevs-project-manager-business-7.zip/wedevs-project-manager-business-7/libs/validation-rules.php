<?php
function pm_pro_required( $value ) {
    return false;
}
